HybridServer
=================
Proyecto base para la realización de la práctica de la asignatura Desarrollo de Aplicaciones para Internet de la Escuela Superior de Ingeniría Informática de la Universidad de Vigo durante el curso 2014/2015.

Autores
=================
Manuel Ramos García - 36151086P
Héctor Riopedre López - 33554236L